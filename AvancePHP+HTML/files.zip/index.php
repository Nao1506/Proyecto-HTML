<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Neko-san a 5km</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Tu CSS -->
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

  <!-- Menú de navegación -->
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="index.php">🐾 Neko-san a 5km</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
          <li class="nav-item"><a class="nav-link" href="colas.php">Colas</a></li>
          <li class="nav-item"><a class="nav-link" href="orejas.php">Orejas</a></li>
          <li class="nav-item"><a class="nav-link" href="trajes.php">Trajes</a></li>
          <li class="nav-item"><a class="nav-link" href="accesorios.php">Accesorios</a></li>
          <li class="nav-item"><a class="nav-link" href="php/logica_catalogo.php">Tienda</a></li>
          <li class="nav-item"><a class="nav-link" href="login.php">Ingresar</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Presentación -->
  <header class="portada text-center">
    <div class="container">
      <h1>Bienvenido a Neko-san a 5km 💗</h1>
      <p>Encuentra accesorios y productos para tu waifu interior.</p>
      <a href="#productos" class="btn boton-rosa">Ver productos</a>
    </div>
  </header>

  <!-- Productos destacados -->
  <main class="container py-5" id="productos">
    <h2 class="text-center mb-4">Productos destacados</h2>
    <div class="row g-4">

      <div class="col-md-4">
        <div class="card producto h-100">
        <img src="Img/zorra.jpg" alt="Descripción de la imagen">

          <div class="card-body">
            <h5 class="card-title">Cola de zorrito pop</h5>
            <p class="card-text">Una cola suave para completar tu estilo.</p>
            <p class="precio">$15.000</p>
            <a href="colas.php" class="btn boton-rosa">Ver producto</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card producto h-100">
          <img src="Img/Coneja.jpg" alt="Descripción de la imagen">
          <div class="card-body">
            <h5 class="card-title">Orejas de conejito pop</h5>
            <p class="card-text">Un accesorio adorable y divertido (No incluye la peluca).</p>
            <p class="precio">$10.000</p>
            <a href="orejas.php" class="btn boton-rosa">Ver producto</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card producto h-100">
        <img src="Img/images.jpg" alt="Descripción de la imagen">
          <div class="card-body">
            <h5 class="card-title">Traje furryto pop</h5>
            <p class="card-text">Un diseño para darle vida a tu personaje.</p>
            <p class="precio">Consultar precio</p>
            <a href="trajes.php" class="btn boton-rosa">Ver producto</a>
          </div>
        </div>
      </div>

    </div>
  </main>

  <footer class="pie text-center py-4">
    <p class="mb-0">© 2026 Mi Tienda Furry · Hecho con amor💗</p>
  </footer>

  <!-- Bootstrap para el menú adaptable; no es código JavaScript propio -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
