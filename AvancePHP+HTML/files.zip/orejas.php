<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Orejas | Mi Tienda Furry</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="index.php">🐾 Neko-san a 5km</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
          <li class="nav-item"><a class="nav-link" href="colas.php">Colas</a></li>
          <li class="nav-item"><a class="nav-link" href="orejas.php">Orejas</a></li>
          <li class="nav-item"><a class="nav-link" href="trajes.php">Trajes</a></li>
          <li class="nav-item"><a class="nav-link" href="accesorios.php">Accesorios</a></li>
          <li class="nav-item"><a class="nav-link" href="php/logica_catalogo.php">Tienda</a></li>
          <li class="nav-item"><a class="nav-link" href="login.php">Ingresar</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <header class="portada text-center"><div class="container">
    <h1>Orejas 🐰</h1><p>Elige tus orejas favoritas.</p>
  </div></header>
  <main class="container py-5"><div class="row g-4">
  <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🐺</div><div class="card-body"><h5>Cola de lobo</h5><p>Diseño gris y esponjoso.</p><p class="precio">$18.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🐱</div><div class="card-body"><h5>Cola de gato</h5><p>Un accesorio sencillo.</p><p class="precio">$12.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
    <div class="col-md-4"><div class="card producto h-100"><div class="imagen-producto">🦊</div><div class="card-body"><h5>Cola de zorro</h5><p>Color naranja y blanco.</p><p class="precio">$15.000</p></div></div></div>
</div></main>
  <footer class="pie text-center py-4">© 2026 Mi Tienda Furry</footer>
</body>
</html>
