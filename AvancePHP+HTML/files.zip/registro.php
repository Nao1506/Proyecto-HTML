<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear cuenta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
  <div class="card producto p-4" style="max-width: 400px; margin: 60px auto;">
    <h2 class="text-center">🐾 Crear cuenta</h2>
    <form action="php/logica_registro.php" method="POST">
      <label>Nombre:</label>
      <input class="form-control mb-3" type="text" name="txt_nombre" required>

      <label>Correo:</label>
      <input class="form-control mb-3" type="email" name="txt_correo" required>

      <label>Contraseña:</label>
      <input class="form-control mb-3" type="password" name="txt_pass" required>

      <button class="btn boton-rosa w-100" type="submit">Registrarme</button>
    </form>
    <p class="text-center mt-3 mb-0">¿Ya tenés cuenta? <a href="login.php">Iniciá sesión</a></p>
  </div>
</body>
</html>
